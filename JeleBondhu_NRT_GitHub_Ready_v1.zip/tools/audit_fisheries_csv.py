"""Independent event-overlap check for locally exported research CSV.

Run in private Colab: python tools/audit_fisheries_csv.py fisheries.csv
Never commit raw event coordinates/catches to a public repository.
"""
import csv,collections,sys,json
from pathlib import Path

def audit(path):
    with open(path,encoding='utf-8-sig',newline='') as f:
        records=list(csv.DictReader(f))
    if not records:raise ValueError('Empty fisheries data')
    cols={x.lower():x for x in records[0]}
    def find(*names):
        for n in names:
            if n in cols:return cols[n]
        return None
    species=find('species','species_scientific_name','scientific_name')
    lat=find('latitude','lat','fishing_event_lat');lon=find('longitude','lon','fishing_event_lon')
    date=find('date','datetime','fishing_event_datetime','sample_date')
    if not all((species,lat,lon,date)):
        raise ValueError('CSV requires species, latitude, longitude, date columns; map your columns explicitly')
    by=collections.defaultdict(set)
    for r in records:
        if not r.get(species) or not r.get(lat) or not r.get(lon) or not r.get(date):continue
        by[r[species]].add((r[date][:10],r[lat].strip(),r[lon].strip()))
    species_names=sorted(by);pairs=[]
    for i,a in enumerate(species_names):
        for b in species_names[i+1:]:
            union=len(by[a]|by[b]);intersection=len(by[a]&by[b]);pairs.append(intersection/union if union else None)
    output={'total_rows':len(records),'species':len(by),'unique_events_across_species':len(set.union(*by.values())) if by else 0,
            'pair_overlap_jaccard_min':min(pairs) if pairs else None,
            'pair_overlap_jaccard_max':max(pairs) if pairs else None,
            'qc':'NOT_INDEPENDENT_VALIDATION; require event IDs, gear comparability, official EEZ polygon and independent environmental matchups'}
    return output

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python tools/audit_fisheries_csv.py exported.csv')
    print(json.dumps(audit(Path(sys.argv[1])),indent=2))
