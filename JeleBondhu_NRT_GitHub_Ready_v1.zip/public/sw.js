/* Offline fallback: never promotes a cached advisory to current status. */
const VERSION='jb-static-v1';const SNAP='jb-snapshot-v1';const STATIC=['./','index.html','styles.css','app.js','about.html','manifest.webmanifest','assets/icon.svg','data/eez.geojson','data/mpas_review.geojson'];
self.addEventListener('install',e=>e.waitUntil(caches.open(VERSION).then(c=>c.addAll(STATIC)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(x=>![VERSION,SNAP].includes(x)).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin)return;
 if(u.pathname.endsWith('/data/latest.json')){
  e.respondWith(fetch(e.request,{cache:'no-store'}).then(async response=>{if(response.ok){const c=await caches.open(SNAP);await c.put(e.request,response.clone())}return response}).catch(async()=>{const c=await caches.open(SNAP);return await c.match(e.request)||new Response('{"schema":"unavailable","cells":[]}',{headers:{'Content-Type':'application/json'}})}));return;
 }
 e.respondWith(caches.match(e.request).then(cached=>cached||fetch(e.request).then(async res=>{if(res.ok){let cache=await caches.open(VERSION);await cache.put(e.request,res.clone())}return res})))
});
