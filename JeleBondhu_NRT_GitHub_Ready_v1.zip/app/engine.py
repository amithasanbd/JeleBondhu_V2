"""Transparent, fail-closed prototype decision rules.

Important: neither a weather forecast nor this software can authorize a voyage.
This module deliberately does not output a positive SAFE status.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, date, timezone
from math import asin, cos, exp, radians, sin, sqrt
from typing import Any


def clamp(x:float, lo:float=0.0, hi:float=1.0)->float:
    return max(lo,min(hi,float(x)))


def score_upper(value:float|None, safe:float,stop:float)->float|None:
    if value is None or stop <= safe:return None
    return clamp((stop-value)/(stop-safe))


def score_lower(value:float|None, safe:float,stop:float)->float|None:
    if value is None or safe <= stop:return None
    return clamp((value-stop)/(safe-stop))


def haversine_km(lat1,lon1,lat2,lon2):
    lat1,lat2=radians(lat1),radians(lat2)
    dlat=lat2-lat1;dlon=radians(lon2-lon1)
    return 12742*asin(sqrt(sin(dlat/2)**2+cos(lat1)*cos(lat2)*sin(dlon/2)**2))


def parse_utc(value: str|None):
    if not value:return None
    try:
        return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone.utc)
    except (ValueError,TypeError):return None


def marine_warning(bmd:dict, now:datetime|None=None):
    """Treat missing / stale / unreviewed warnings as unknown, never clear."""
    now=now or datetime.now(timezone.utc)
    issue=parse_utc(bmd.get('issued_at_utc'))
    expiry=parse_utc(bmd.get('valid_until_utc'))
    checked=parse_utc(bmd.get('checked_at_utc'))
    if bmd.get('verification')!='VERIFIED' or not issue or not expiry or not checked:
        return 'UNKNOWN','BMD_NOT_VERIFIED'
    if now>expiry or issue>now or checked>now or expiry<=issue or checked<issue or (now-checked).total_seconds()>6*3600:
        return 'UNKNOWN','BMD_STALE_OR_INVALID'
    signal=bmd.get('signal_number')
    if not isinstance(signal,int) or signal<0:return 'UNKNOWN','BMD_SIGNAL_MISSING'
    scope=bmd.get('applies_to')
    if scope not in ('ALL_BAY','NORTH_BAY','COASTAL_ZONES','NO_ACTIVE_MARINE_WARNING'):
        return 'UNKNOWN','BMD_SCOPE_UNKNOWN'
    if signal>=4:return 'STOP','BMD_DANGER_SIGNAL'
    if signal==3:return 'CAUTION','BMD_CAUTION_SIGNAL_3'
    if signal in (1,2):return 'CAUTION','BMD_ADVISORY_SIGNAL'
    if scope!='NO_ACTIVE_MARINE_WARNING':return 'UNKNOWN','BMD_ZERO_WITH_ACTIVE_SCOPE'
    return 'CLEAR','BMD_REVIEWED_NO_ACTIVE_WARNING'


def active_bans(rules:dict,query_date:date,species:str):
    """Dated official confirmations only, never a yearly auto-repeat."""
    matches=[]
    for r in rules.get('verified_rules',[]):
        try:
            if date.fromisoformat(r['from']) <= query_date <= date.fromisoformat(r['through']):
                if r['species']=='all' or r['species']==species:matches.append(r)
        except (KeyError,ValueError,TypeError):continue
    return matches


def evaluate_sustainability(cell:dict,rules:dict,species:str,when:date):
    bans=active_bans(rules,when,species)
    if bans:return {'score':0.0,'status':'NO_GO','reason':bans[0]['id'],'authority':bans[0]['source'],'verified':True}
    # There are no georeferenced signed gear-specific no-take masks in this release.
    # Do not assert anything is compliant merely because no dated ban matched.
    notes=[]
    if cell.get('mpa_names'):notes.append('MPA_BOUNDARY_CHECK_GEAR_RULES')
    if cell.get('ifa'):notes.append('IFA_VESSEL_RULES_REQUIRE_REVIEW')
    if species in ('hilsa','jatka') and (when.month>=11 or when.month<=6):
        notes.append('HILSA_NURSERY_SEASON_CONTEXT')
    return {'score':None,'status':'REVIEW_REQUIRED','reason':notes[0] if notes else 'LEGAL_CLEARANCE_NOT_VERIFIED','notes':notes,'verified':False}


def classify_hazards(hourly:list[dict], vessel:dict):
    """Evaluate at least 72-hour series; no hazards are silently dropped."""
    if not hourly:return {'score':None,'status':'UNKNOWN','reason':'MISSING_MARINE_WEATHER','first_risk_h':None}
    first_risk=None;first_stop=None;min_score=1.0;first_score=None;critical_missing=False
    for idx,row in enumerate(hourly[:72]):
        scores=[
            score_upper(row.get('wave_m'),vessel['wave_safe_m'],vessel['wave_stop_m']),
            score_upper(row.get('wind_kn'),vessel['wind_safe_kn'],vessel['wind_stop_kn']),
            score_upper(row.get('gust_kn'),vessel['gust_safe_kn'],vessel['gust_stop_kn']),
            score_lower(row.get('visibility_m'),9300,1000),
        ]
        code=row.get('weather_code')
        scores.append(None if code is None else (0 if int(code) in (95,96,99) else 1))
        if any(x is None for x in scores):critical_missing=True;continue
        val=min(scores)
        if idx==0:first_score=val
        min_score=min(val,min_score)
        if val<.5 and first_risk is None:first_risk=idx
        if val<=0 and first_stop is None:first_stop=idx
    if len(hourly)<72 or critical_missing:
        return {'score':None,'status':'UNKNOWN','reason':'INCOMPLETE_72H_HAZARD_INPUTS','first_risk_h':first_risk}
    if first_stop == 0:
        status='HAZARD_NOW'
    elif first_risk is not None:
        status='RISK_DURING_WINDOW'
    else:status='SCREEN_NO_RISK_DETECTED'
    return {'score':round(min_score,3),'score_now':round(first_score,3) if first_score is not None else None,'status':status,'reason':status,'first_risk_h':first_risk}


def approximate_trip(cell,landing,vessel,fish_hours=6):
    """Straight-line*1.25 is NOT navigation or validated sea routing."""
    d=haversine_km(cell['lat'],cell['lon'],landing['lat'],landing['lon'])*1.25
    one_way_hours=d/(vessel['speed_kn']*1.852)
    return {'approx_distance_km':round(d,1),'approx_trip_hours':round(2*one_way_hours+fish_hours,1),'route_verified':False}


def exploratory_suitability(ocean:dict):
    """Explicit environmental screening proxy, NOT thesis PAI, NOT fish catch skill."""
    chl=ocean.get('chl_mg_m3');sst=ocean.get('sst_c');salt=ocean.get('sss_psu')
    if any(x is None for x in (chl,sst,salt)):
        return {'screen':None,'status':'UNAVAILABLE','reason':'SST_SSS_CHL_REQUIRED','pai':None}
    if not (0<=chl<=80 and 5<=sst<=40 and 0<=salt<=45):
        return {'screen':None,'status':'INVALID','reason':'RANGE_CHECK_FAILED','pai':None}
    # Explicitly illustrative nonlinear screening only: does not assert optimal biology.
    import math
    chl_response=clamp(math.log1p(chl)/math.log1p(6))
    thermal_response=clamp(1-abs(sst-28)/10)
    salinity_response=clamp(1-abs(salt-30)/20)
    return {'screen':round(.40*chl_response+.30*thermal_response+.30*salinity_response,3),
            'status':'UNVALIDATED_ENVIRONMENTAL_SCREEN','reason':'NON_SPECIES_SPECIFIC_PROXY','pai':None,
            'components':{'chl_response':round(chl_response,3),'thermal_response':round(thermal_response,3),'salinity_response':round(salinity_response,3)}}


def final_decision(suitability,safety,sustain,bmd_state,confidence:float|None,trip=None):
    """Hard legal/critical weather stops are shown, unknowns never become SAFE.

    NO_GO is for verified regulatory closures or a critical physical hazard.
    Every other result remains NO_ADVISORY/CAUTION until external certification.
    """
    if sustain.get('status')=='NO_GO':return 'NO_GO',sustain['reason']
    if bmd_state[0]=='STOP':return 'NO_GO',bmd_state[1]
    if safety.get('status')=='HAZARD_NOW':return 'NO_GO','CRITICAL_FORECAST_HAZARD_NOW'
    if trip and trip.get('return_margin_fraction') is not None and trip['return_margin_fraction']<0:
        return 'NO_GO','FORECAST_RISK_BEFORE_ESTIMATED_RETURN'
    if bmd_state[0]=='UNKNOWN':return 'NO_ADVISORY',bmd_state[1]
    if confidence is None or confidence<.3:return 'NO_ADVISORY','INSUFFICIENT_DATA_CONFIDENCE'
    if safety.get('status')=='UNKNOWN':return 'NO_ADVISORY','INCOMPLETE_SAFETY_INPUTS'
    if suitability.get('status') in ('UNAVAILABLE','INVALID'):return 'NO_ADVISORY','FISHING_SUITABILITY_UNAVAILABLE'
    if sustain.get('status')!='VERIFIED_OPEN':return 'CAUTION','LEGAL_RESTRICTIONS_REQUIRE_REVIEW'
    if not trip or not trip.get('route_verified'):return 'CAUTION','SEA_RETURN_ROUTE_UNVERIFIED'
    return 'CAUTION','RESEARCH_NOT_OPERATIONALLY_CERTIFIED'
