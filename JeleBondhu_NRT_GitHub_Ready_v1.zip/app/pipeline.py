"""Generate a reproducible lightweight NRT *research* snapshot.

Run: python -m app.pipeline
No credentials embedded. Do not produce synthetic live observations.
"""
from __future__ import annotations
import argparse,json,sys,os
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from shapely.geometry import Point,shape
from app.engine import (marine_warning,active_bans,evaluate_sustainability,classify_hazards,
                        exploratory_suitability,approximate_trip,final_decision)
from app.providers import fetch_openmeteo,fetch_cmems

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT/'public'/'data'
CFG=ROOT/'config'

def load(path):return json.loads(Path(path).read_text(encoding='utf-8'))

def write_atomic(path,data):
    tmp=Path(str(path)+'.part')
    tmp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    os.replace(tmp,path)

def nearest_landing(cell):
    # Proxy departure sites; NOT nautical route or guaranteed accessible harbours.
    sites=[{'name':'Kuakata approximate','lat':21.82,'lon':90.12},
           {'name':'Coxs Bazar approximate','lat':21.44,'lon':91.98},
           {'name':'Mongla approximate','lat':22.49,'lon':89.59}]
    from app.engine import haversine_km
    return min(sites,key=lambda s:haversine_km(cell['lat'],cell['lon'],s['lat'],s['lon']))

def mpa_layer():
    fc=load(DATA/'mpas_review.geojson')
    return [(x['properties']['name'],shape(x['geometry'])) for x in fc.get('features',[])]

def main(force_empty=False,only=0):
    now=datetime.now(timezone.utc);today=now.astimezone(ZoneInfo('Asia/Dhaka')).date()
    settings=load(CFG/'settings.json');rules=load(CFG/'ban_rules_bd.json');bmd=load(CFG/'bmd_bulletin.json')
    cells=load(DATA/'grid.json')['points']
    if only>0:cells=cells[:only]  # test only; never publish partial grid as full EEZ
    mpa=mpa_layer()
    for c in cells:
        loc=Point(c['lon'],c['lat'])
        c['mpa_names']=[n for n,poly in mpa if poly.intersects(loc)]
    bmd_state=marine_warning(bmd,now)
    if force_empty:weather={};errors=[{'error':'NO_NETWORK_TEST'}];cmems={};cmems_info={'status':'DISABLED_TEST'}
    else:
        weather,errors=fetch_openmeteo(cells,now,settings['weather']['batch_size'],settings['weather']['timeout_seconds'])
        cmems,cmems_info=fetch_cmems(cells,now,settings)
    entries=[]
    n_weather=0;n_cmems=0
    for cell in cells:
        w=weather.get(cell['id'],{});hours=w.get('hours',[])
        if len(hours)==72:n_weather+=1
        oc=cmems.get(cell['id'],{}).copy()
        if all(x in oc for x in ('thetao','so','chl')):n_cmems+=1
        ocean={'sst_c':oc.get('thetao'),'sss_psu':oc.get('so'),'chl_mg_m3':oc.get('chl')}
        # Do not use OpenMeteo SST in a three-variable CMEMS model.
        suitability=exploratory_suitability(ocean)
        # Score availability is explicitly a proxy, not validated skill.
        availability=(sum(x is not None for x in ocean.values())/3)*.5+(.5 if len(hours)==72 else 0)
        confidence=round(availability,3)
        result={'id':cell['id'],'lat':cell['lat'],'lon':cell['lon'],'depth_m':cell['depth_m'],
                'ifa':cell['ifa'],'mpas_review':cell.get('mpa_names',[]),
                'ocean':ocean,'environment':suitability,'confidence_proxy':confidence,
                'weather':{'wave_m':hours[0]['wave_m'] if hours else None,
                           'wind_kn':hours[0]['wind_kn'] if hours else None,
                           'gust_kn':hours[0]['gust_kn'] if hours else None,
                           'visibility_m':hours[0]['visibility_m'] if hours else None,
                           'first_time_utc':hours[0]['time_utc'] if hours else None},
                'vessels':{}}
        for vessel_name,vessel in settings['vessels'].items():
            risk=classify_hazards(hours,vessel)
            trip=approximate_trip(cell,nearest_landing(cell),vessel,settings['default_fishing_hours'])
            if risk.get('status')!='UNKNOWN':
                W=risk['first_risk_h'] if risk.get('first_risk_h') is not None else 72
                rt=trip['approx_trip_hours']
                margin=(W-rt)/rt if rt>0 else None
                trip['return_margin_fraction']=round(margin,3) if margin is not None else None
                trip['earliest_local_cell_hazard_h']=W
                trip['margin_method']='APPROXIMATE_CELL_ONLY_NOT_ROUTE_VERIFIED'
            species_out={}
            for species in ['other','hilsa','jatka']:
                sustain=evaluate_sustainability(cell,rules,species,today)
                classification,reason=final_decision(suitability,risk,sustain,bmd_state,confidence,trip)
                species_out[species]={'class':classification,'reason':reason,'sustainability':sustain['status'],
                                      'legal_reason':sustain['reason']}
            result['vessels'][vessel_name]={'safety':risk,'return_proxy':trip,'species':species_out}
        entries.append(result)
    snapshot={'schema':'jelebondhu.nrt.v1','generated_at_utc':now.isoformat(timespec='seconds'),
              'display_date_bst':str(today),'research_only':True,
              'is_operational_advice':False,'is_validated_species_prediction':False,
              'bmd':{'status':bmd_state[0],'reason':bmd_state[1],
                     'checked_at_utc':bmd.get('checked_at_utc'), 'warning_url':bmd.get('warning_url'),
                     'fishermen_forecast_url':bmd.get('fishermen_forecast_url')},
              'source_health':{'openmeteo_cells_72h':n_weather,'cmems_complete_cells':n_cmems,
                               'openmeteo_failures':errors,'cmems':cmems_info},
              'model':settings['model'], 'rule_review_date':rules['last_reviewed'],
              'data_attribution':['Open-Meteo (underlying model providers)','Copernicus Marine Service','BMD official bulletins'],
              'caveat_bn':'গবেষণা পরীক্ষামূলক। এটি সমুদ্রে যাওয়ার নিরাপত্তা অনুমোদন নয়। সরকারি সতর্কতা যাচাই করুন।',
              'cells':entries}
    write_atomic(DATA/'latest.json',snapshot)
    print('Saved',len(entries),'cells; 72h weather',n_weather,'CMEMS complete',n_cmems,'BMD',bmd_state)
    return snapshot

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--no-network-test',action='store_true')
    parser.add_argument('--limit',type=int,default=0)
    a=parser.parse_args();main(a.no_network_test,a.limit)
