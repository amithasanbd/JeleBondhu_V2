"""Optional hosted HTTP backend. GitHub Pages mode uses the same snapshot JSON.

Start: uvicorn app.api:api --host 0.0.0.0 --port 8000
Read-only endpoints. A public refresh endpoint is intentionally disabled.
"""
from pathlib import Path
import json
from fastapi import FastAPI,HTTPException
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from app.pipeline import DATA,ROOT
api=FastAPI(title='JeleBondhu Research API',version='1.0.0',description='Experimental only; not navigational or legal clearance')

def snapshot():
    p=DATA/'latest.json'
    if not p.exists():raise HTTPException(status_code=503,detail='NO_VERIFIED_SNAPSHOT')
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):raise HTTPException(status_code=503,detail='SNAPSHOT_UNREADABLE')

@api.get('/api/health')
def health():
    s=snapshot()
    return {'service':'JeleBondhu','status':'RESEARCH_ONLY','generated_at_utc':s.get('generated_at_utc'),
            'cells':len(s.get('cells',[])),'bmd':s.get('bmd',{}).get('status'),'operational_advice':False}

@api.get('/api/snapshot')
def current():return JSONResponse(snapshot(),headers={'Cache-Control':'no-cache, must-revalidate','X-JeleBondhu-Research-Only':'true'})

@api.get('/api/cells/{cell_id}')
def cell(cell_id:str):
    if len(cell_id)>80 or not all(c.isalnum() or c in '-_' for c in cell_id):raise HTTPException(status_code=400,detail='INVALID_ID')
    for c in snapshot().get('cells',[]):
        if c.get('id')==cell_id:return c
    raise HTTPException(status_code=404,detail='GRID_CELL_NOT_FOUND')

api.mount('/',StaticFiles(directory=str(ROOT/'public'),html=True),name='static')
