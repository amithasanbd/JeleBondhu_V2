"""Network adapters. No invented fallback observations, no browser API keys."""
from __future__ import annotations
import os
from datetime import datetime,timezone
from typing import Any
import requests

MARINE='https://marine-api.open-meteo.com/v1/marine'
WEATHER='https://api.open-meteo.com/v1/forecast'
MARINE_VARIABLES='wave_height,wave_period,swell_wave_height,ocean_current_velocity,sea_surface_temperature'
WEATHER_VARIABLES='wind_speed_10m,wind_gusts_10m,visibility,weather_code'


def fetch_batch(url,points,variables,timeout=35):
    args={'latitude':','.join(str(x['lat']) for x in points),
          'longitude':','.join(str(x['lon']) for x in points),
          'hourly':variables,'timezone':'UTC','forecast_days':4,'cell_selection':'sea'}
    if url==WEATHER:
        args.pop('cell_selection',None);args['wind_speed_unit']='kn'
    resp=requests.get(url,params=args,headers={'User-Agent':'JeleBondhu-Research-Prototype/1.0 (noncommercial)'},timeout=timeout)
    resp.raise_for_status();data=resp.json()
    data=data if isinstance(data,list) else [data]
    if len(data)!=len(points):raise ValueError(f'{url}: expected {len(points)} locations, got {len(data)}')
    for part in data:
        if part.get('error'):raise ValueError(str(part.get('reason','Provider error')))
        if not part.get('hourly',{}).get('time'):raise ValueError('Missing hourly time axis')
    return data


def hourly_for_pair(marine:dict,weather:dict,now:datetime):
    """Join by explicit UTC forecast hours; never align by array position."""
    m=marine['hourly'];w=weather['hourly']
    mi={t:i for i,t in enumerate(m['time'])};wi={t:i for i,t in enumerate(w['time'])}
    common=sorted(set(mi)&set(wi))
    result=[]
    for t in common:
        try:
            stamp=datetime.fromisoformat(t).replace(tzinfo=timezone.utc)
        except ValueError:continue
        if stamp < now.replace(minute=0,second=0,microsecond=0):continue
        im,iw=mi[t],wi[t]
        def get(d,key,i):
            values=d.get(key,[])
            val=values[i] if len(values)>i else None
            return float(val) if val is not None else None
        code=get(w,'weather_code',iw)
        result.append({'time_utc':stamp.isoformat(),
                       'wave_m':get(m,'wave_height',im),
                       'wind_kn':get(w,'wind_speed_10m',iw),
                       'gust_kn':get(w,'wind_gusts_10m',iw),
                       'visibility_m':get(w,'visibility',iw),
                       'weather_code':code,
                       'swell_m':get(m,'swell_wave_height',im)})
        if len(result)==72:break
    return result


def fetch_openmeteo(cells,now,batch_size=12,timeout=35):
    records={};failures=[]
    for start in range(0,len(cells),batch_size):
        batch=cells[start:start+batch_size]
        try:
            marine=fetch_batch(MARINE,batch,MARINE_VARIABLES,timeout)
            weather=fetch_batch(WEATHER,batch,WEATHER_VARIABLES,timeout)
            for p,m,w in zip(batch,marine,weather):
                records[p['id']]={'hours':hourly_for_pair(m,w,now),
                                  'sea_surface_temperature_c':None,
                                  'marine_grid_lat':m.get('latitude'),'marine_grid_lon':m.get('longitude'),
                                  'weather_grid_lat':w.get('latitude'),'weather_grid_lon':w.get('longitude')}
                ss=m['hourly'].get('sea_surface_temperature',[])
                if ss:
                    valid=[v for v in ss if v is not None]
                    if valid:records[p['id']]['sea_surface_temperature_c']=float(valid[0])
        except (requests.RequestException,ValueError,KeyError,TypeError) as err:
            failures.append({'start':start,'count':len(batch),'error':type(err).__name__})
    return records,failures


def fetch_cmems(cells,now,config):
    """Optional CMEMS enrichment, bulk-loading a small spatial subset once.

    Credential-free mode is fully supported and visibly marked unconfigured.
    Never silently fill model fields from another product or climatology.
    """
    user=os.getenv('COPERNICUSMARINE_SERVICE_USERNAME')
    pwd=os.getenv('COPERNICUSMARINE_SERVICE_PASSWORD')
    if not user or not pwd:return {},{'status':'NOT_CONFIGURED','reason':'CMEMS_SECRETS_MISSING'}
    try:
        import copernicusmarine
        import numpy as np
        variables={}
        versions={}
        for dataset,keys in [(config['copernicus']['dataset_physics'],['thetao','so','uo','vo']),
                              (config['copernicus']['dataset_bgc'],['chl'])]:
            ds=copernicusmarine.open_dataset(dataset_id=dataset,username=user,password=pwd)
            cut=np.datetime64(now.astimezone(timezone.utc).replace(tzinfo=None))
            available=np.asarray(ds['time'].values)
            earlier=available[available<=cut]
            if len(earlier)==0:continue
            stamp=earlier[-1]
            # Do not describe stale analyses as NRT.
            age_hours=(cut-stamp)/np.timedelta64(1,'h')
            if age_hours>config['copernicus'].get('max_data_age_hours',72):continue
            subset=ds[keys] if all(key in ds for key in keys) else ds[[k for k in keys if k in ds]]
            subset=subset.sel(time=stamp)
            if 'depth' in subset.dims:subset=subset.isel(depth=0)
            lat=next((k for k in ('latitude','lat') if k in subset.dims),None)
            lon=next((k for k in ('longitude','lon') if k in subset.dims),None)
            if not lat or not lon:continue
            # Limit the lazy remote request to Bangladesh's offshore envelope.
            subset=subset.sel({lat:slice(17.5,23.8),lon:slice(88.5,93.1)}).load()
            if not subset.sizes.get(lat) or not subset.sizes.get(lon):continue
            for key in keys:
                if key in subset:variables[key]=(subset[key],lat,lon)
            versions[dataset]={'time_utc':np.datetime_as_string(stamp,unit='s')+'Z','age_hours':round(float(age_hours),1)}
        result={}
        for cell in cells:
            record={};stamps={}
            for key,(arr,lat,lon) in variables.items():
                value=arr.sel({lat:cell['lat'],lon:cell['lon']},method='nearest').values
                value=float(np.asarray(value).squeeze())
                if np.isfinite(value):record[key]=value
            if record:result[cell['id']]=record
        return result,{'status':'FETCHED' if variables else 'UNAVAILABLE','points':len(result),'dataset_times':versions}
    except Exception as exc:
        return {},{'status':'FAILED','reason':type(exc).__name__,
                   'note':'Review dataset IDs, variable coverage, and service availability; no fallback substituted'}
