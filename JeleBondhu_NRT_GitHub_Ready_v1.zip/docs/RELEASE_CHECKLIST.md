# JeleBondhu release checklist

## Mandatory before any public demonstration

- [ ] Rotate previously shared Copernicus password; ensure old credential is disabled.
- [ ] Restrict Drive historical workbook sharing and prohibit uploading private fisheries data.
- [ ] Confirm `public/data/latest.json` has `research_only: true` and `is_operational_advice: false`.
- [ ] Read current BMD marine warning AND fishermen forecast, confirm issue and valid times, record in config with source.
- [ ] Confirm 2026/27 fisheries ban dates with MoFL/DoF and review MPA restrictions against current Gazettes.
- [ ] Verify Inshore Fishing Area geometry after repair and inspect coastline/GEBCO conflict areas.
- [ ] Run tests and inspect source-health failure list.
- [ ] Check PWA offline mode ALWAYS displays a stale-data warning for an old snapshot.
- [ ] Check poor-network and mobile-screen usability with fisher representatives.
- [ ] Acknowledge absence of independently validated species-specific fishing prediction skill.
- [ ] Confirm Open-Meteo noncommercial use terms and source attribution.

## System still requiring work

- [ ] Exact frozen PAI weights and month-region quantile mapping from verified thesis artifact.
- [ ] Full trip route optimization on a verified marine graph and vessel-specific safety limits.
- [ ] Zone/gear-specific MPA and closure overlays checked by legal authority.
- [ ] BMD API/data-sharing agreement and operational warning verification.
- [ ] Prospective CPUE independence/coverage, block cross-validation and uncertainty.
- [ ] Offshore timely alert communications beyond a cached PWA (e.g. VHF/SMS/shore network after approvals).
