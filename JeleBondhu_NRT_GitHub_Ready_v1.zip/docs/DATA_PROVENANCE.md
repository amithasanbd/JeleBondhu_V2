# Data inventory and provenance

| Input | Source status | Public repository handling |
|---|---|---|
| 1995–2025 master workbook | Google Drive raw 1.35 GB; not ingested into this artifact | Not included; requires Colab processing and frozen calibration export |
| 2020–2025 commercial fisheries | User-uploaded in situ workbook; event independence still under review | Not included, private; event audit tooling supplied |
| 2022–2024 fishing grounds | Supplied workbook and manual; geographic extents approximate | 4 approximate review-only bounding polygons |
| EEZ shapefile | User-supplied EPSG:4326 valid polygon | Full research geometry in config; simplified display layer |
| IFA shapefile | User-supplied invalid multipolygon repaired with Shapely make_valid | Review layer, not unconditional legal permission |
| GEBCO | User-uploaded NetCDF bathymetry | Grid-center depth sample, no nautical chart |
| MPAs 2026 | User manual, some official vertices, SoNG approximation | Seven caution overlays; no universal no-take assumptions |
| CMEMS | Official global model analysis/forecast | Optional authenticated backend connector, timestamps, no embedded credentials |
| Open-Meteo | Public free noncommercial API | Model hourly data via Python backend, strict QC |
| BMD | Marine Warning and Fishermen Forecast | Operator-reviewed dated bulletin only, unknown until verified |
| R2 | Existing old offline-only HTML | Inspected as design reference, not republished in the public repository |

**Critical interpretation:** There are no independent vessel telemetry, continuously approved BMD clearance, publication-grade CPUE skill, or original frozen model weights in this package. No-go and caution classifications are provisional models and selected verified legal dates, not an approved maritime traffic-control function.
