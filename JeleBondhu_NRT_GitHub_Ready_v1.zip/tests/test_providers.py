from datetime import datetime,timezone,timedelta
from app.providers import hourly_for_pair,fetch_openmeteo

def test_join_by_hours_not_positional_index():
    start=datetime(2026,11,25,12,tzinfo=timezone.utc)
    times=[(start+timedelta(hours=i)).strftime('%Y-%m-%dT%H:%M') for i in range(73)]
    marine={'hourly':{'time':times,'wave_height':[.3]*73,'wave_period':[5]*73,
                      'swell_wave_height':[.2]*73,'sea_surface_temperature':[28]*73}}
    weather={'hourly':{'time':times[1:],'wind_speed_10m':[10]*72,
                       'wind_gusts_10m':[12]*72,'visibility':[8000]*72,'weather_code':[0]*72}}
    joined=hourly_for_pair(marine,weather,start)
    assert len(joined)==72
    assert joined[0]['time_utc'].startswith('2026-11-25T13:00')
    assert joined[0]['wind_kn']==10

def test_empty_provider_returns_unknown_not_synthetic():
    from app.engine import classify_hazards
    vessel={'wave_safe_m':.5,'wave_stop_m':1,'wind_safe_kn':10,'wind_stop_kn':16,'gust_safe_kn':16,'gust_stop_kn':22}
    assert classify_hazards([],vessel)['status']=='UNKNOWN'
