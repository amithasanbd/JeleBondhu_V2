from datetime import date,datetime,timezone,timedelta
import json
from pathlib import Path
from app.engine import *
from app.pipeline import main,DATA,ROOT

def rules():return json.loads((ROOT/'config/ban_rules_bd.json').read_text())
def test_ban_2026_all():assert active_bans(rules(),date(2026,4,25),'other')[0]['id']=='SEA_ALL_2026'
def test_hilsa_ban_2026():assert active_bans(rules(),date(2026,10,20),'hilsa')[0]['id']=='HILSA_2026'
def test_hilsa_species_specific():assert not active_bans(rules(),date(2026,10,20),'other')
def test_jatka_nov_2026():assert active_bans(rules(),date(2026,11,25),'jatka')[0]['id']=='JATKA_2026_27'
def test_no_unverified_2027_april_ban():assert not active_bans(rules(),date(2027,4,25),'other')
def test_missing_bmd_unknown():assert marine_warning({'verification':'UNVERIFIED'})[0]=='UNKNOWN'
def test_stale_bmd_unknown():
    n=datetime(2026,11,25,tzinfo=timezone.utc)
    b={'verification':'VERIFIED','issued_at_utc':(n-timedelta(hours=9)).isoformat(),
       'valid_until_utc':(n+timedelta(hours=1)).isoformat(),
       'checked_at_utc':(n-timedelta(hours=7)).isoformat(),
       'signal_number':0,'applies_to':'NO_ACTIVE_MARINE_WARNING'}
    assert marine_warning(b,n)[0]=='UNKNOWN'
def test_closure_overrides_unverified_bmd():
    dec,why=final_decision({'status':'UNAVAILABLE'},{'status':'UNKNOWN'},
                             {'status':'NO_GO','reason':'SEA_ALL_2026'},('UNKNOWN','BMD_NOT_VERIFIED'),0.1)
    assert dec=='NO_GO'
def test_low_suitability_not_no_go():
    dec,why=final_decision({'status':'UNVALIDATED_ENVIRONMENTAL_SCREEN','screen':0.02},
        {'status':'SCREEN_NO_RISK_DETECTED','score':1},
        {'status':'REVIEW_REQUIRED'},('CLEAR','BMD_REVIEWED_NO_ACTIVE_WARNING'),.8)
    assert dec=='CAUTION'
def test_hazard_instant_no_go():
    v=json.loads((ROOT/'config/settings.json').read_text())['vessels']['country']
    hours=[{'wave_m':2,'wind_kn':7,'gust_kn':8,'visibility_m':10000,'weather_code':0} for _ in range(72)]
    s=classify_hazards(hours,v)
    assert s['status']=='HAZARD_NOW'
    assert final_decision({},s,{'status':'REVIEW_REQUIRED'},('UNKNOWN','BMD_NOT_VERIFIED'),.8)[0]=='NO_GO'
def test_incomplete_hazards_unknown():
    v=json.loads((ROOT/'config/settings.json').read_text())['vessels']['country']
    h=[{'wave_m':.3,'wind_kn':6,'gust_kn':9,'visibility_m':None,'weather_code':0} for _ in range(72)]
    assert classify_hazards(h,v)['status']=='UNKNOWN'
def test_closures_future_not_assumed():
    assert evaluate_sustainability({'ifa':True,'mpa_names':[]},rules(),'other',date(2027,5,1))['status']=='REVIEW_REQUIRED'
def test_environment_missing_never_fabricated():assert exploratory_suitability({'sst_c':29,'sss_psu':30,'chl_mg_m3':None})['screen'] is None
def test_bad_sst_rejected():assert exploratory_suitability({'sst_c':99,'sss_psu':30,'chl_mg_m3':2})['status']=='INVALID'
def test_grid_point_exists():
    g=json.loads((DATA/'grid.json').read_text())
    assert len(g['points'])>80
    assert all(17<r['lat']<25 and 88<r['lon']<94 and r['depth_m']>0 for r in g['points'])
def test_never_certified_safe():
    x=final_decision({'status':'UNVALIDATED_ENVIRONMENTAL_SCREEN'},
        {'status':'SCREEN_NO_RISK_DETECTED'},{'status':'VERIFIED_OPEN'},('CLEAR','REVIEWED'),1,{'route_verified':True})
    assert x[0]!='SAFE'

def test_negative_return_margin_prevents_departure():
    s={'status':'RISK_DURING_WINDOW','score':.2}
    trip={'return_margin_fraction':-.5,'route_verified':False}
    result=final_decision({'status':'UNAVAILABLE'},s,{'status':'REVIEW_REQUIRED'},('UNKNOWN','BMD_NOT_VERIFIED'),.1,trip)
    assert result==('NO_GO','FORECAST_RISK_BEFORE_ESTIMATED_RETURN')
