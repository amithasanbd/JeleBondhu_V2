# JeleBondhu | জেলেবন্ধু — Near-Real-Time Research WebApp (v1.0)

**Status:** working-code research prototype with a static low-data PWA, scheduled Python data backend, optional FastAPI read-only backend, verification gates, and automated tests. **NOT** an approved navigational, maritime-weather, legal, or fishing-abundance advisory. Do not use its outputs as a sole basis for setting out to sea. No claim of validated fish catch prediction is made.

## What is implemented

- Real API connectors: Open-Meteo Marine (`wave_height`, `wave_period`, `swell_wave_height`, `ocean_current_velocity`, `sea_surface_temperature`) and atmospheric Weather (`wind_speed_10m`, `wind_gusts_10m`, `visibility`, `weather_code`). The Python backend makes requests in batches, time-aligns hourly model data, and performs 72-hour checks.
- Optional CMEMS global operational physical/BGC lazy access, enabled **only** when new credential secrets exist. The ingestion returns `UNAVAILABLE` for missing or stale critical sources. Product IDs remain external configuration.
- 140 true EEZ/GEBCO-filtered offshore sample cells at 0.25° spacing. The grid is generated from the supplied Bangladesh EEZ shapefile, manually repaired IFA geometry, and GEBCO seabed elevation. Simplified EEZ GeoJSON is **visual display only**; a full-resolution derived EEZ GeoJSON is retained in `config/eez_full.geojson` for research use.
- Triple-filter logic: environmental screening, vessel-specific 72-hour hazard screening and regulation/MPA contextual review. Confirmed dated bans can override other filters. Unknown official warnings, route safety, and species-specific model skill are never shown as certified clearances.
- Seven **review-only MPA overlays** reconstructed from the supplied 2026 manual. Their boundaries and legal restrictions are not authoritative; do not equate an MPA boundary with universal no-take legislation. Four fishing-ground bounding rectangles are illustrative only.
- Bangla-first accessible interface, English toggle, three big selectors, touch-friendly 2D lightweight SVG map without commercial basemaps, basic audio via browser speech synthesis (only where device voice support exists), printable information card, PWA offline caching, explicit snapshot staleness detection, and voluntary one-time approximate device geolocation.
- Read-only FastAPI: `/api/health`, `/api/snapshot`, `/api/cells/{id}`.
- GitHub Actions scheduler and Pages publication, with tests; separate independent local API deployment if desired.

## Security before first use — mandatory

1. **Immediately rotate** the Copernicus password that was pasted into chat. It is **not** included in any code or files in this repository.
2. Restrict the original historical 1.35 GB Google Drive workbook's link sharing; earlier review found public edit access. Do not put this workbook, vessel coordinates, catches, identifiable survey responses, or passwords in GitHub Pages.
3. For a GitHub public repository, create repo secrets `CMEMS_USERNAME` and `CMEMS_PASSWORD` from the **new** credentials, if CMEMS access is desired. Open-Meteo does not need an API key under its applicable non-commercial terms.
4. The source files and example snapshots intentionally contain **no verified BMD clearance**; they will return **NO_ADVISORY**, not a fictional “Safe” recommendation.

## Quick start — local

```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q             # first install: pip install -r requirements-dev.txt
python -m app.pipeline --no-network-test # creates verified absence-of-network test snapshot
uvicorn app.api:api --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000. To pull genuine Open-Meteo forecasts, run:

```bash
python -m app.pipeline
```

On a public network this will request approximately 140 ocean grid cells in 12-coordinate batches. All errors are recorded in the snapshot; the backend does not fabricate missing measurements. For local full CMEMS integration install `pip install -r requirements-cmems.txt` and set the two environment variables above. CMEMS dataset availability, access terms, forecast timings, and variable names can evolve, so inspect the live catalog and logs.

**No-internet environments:** The included `public/data/latest.json` contains deliberate `NO_ADVISORY`/unverified research data and geometry, not simulated ocean conditions. The app therefore still opens and shows the grid but does not claim a live forecast.

## GitHub Pages — public deployment

1. Create a new **public** GitHub repository, default branch `main`.
2. Upload **all contents of this extracted folder** at the repository root, including `.github/workflows/publish.yml`, `app`, `config`, `public`, and `requirements*`. GitHub's web uploader can exclude hidden dotfolders, so verify `.github` and `.gitignore` are present; Git CLI is more reliable.
3. In **Settings → Pages**, select **Source: GitHub Actions**.
4. Go to **Settings → Secrets and variables → Actions** and add `CMEMS_USERNAME` and `CMEMS_PASSWORD` (new/rotated values) if enabling Copernicus Marine. Never add them to README, workflow YAML or JS.
5. Open **Actions → JeleBondhu dynamic research snapshot and GitHub Pages → Run workflow**. The workflow attempts the NRT data fetch, executes tests, and publishes the `public/` folder.
6. The **deployment URL** appears in GitHub Actions' deployment status / Settings → Pages after a successful run. GitHub Pages hosts static files only; scheduled Python is run in GitHub Actions at 00:13, 06:13, 12:13 and 18:13 **UTC**, and schedules may be delayed. It is *near-real-time snapshots*, not continuous server execution or push warnings.
7. New commits to `main` also publish an updated snapshot. `bmd_bulletin.json` and `ban_rules_bd.json` are reviewed manually and should not be automatically classified as official fact.

**Free-tier notes:** GitHub Pages and Actions have policies/usage limits. Open-Meteo's free endpoint is for noncommercial use with attribution and no guaranteed availability. This is a public noncommercial research demonstration, not a commercial fishing-safety service.

## Live BMD review protocol

BMD offers published warnings/fishermen-forecast pages, not a verified public machine-readable warning API in this package. An operator should **inspect the actual official bulletin** and update `config/bmd_bulletin.json`:

- `verification: "VERIFIED"` only after source verification;
- `checked_at_utc` (last human check), `issued_at_utc`, and `valid_until_utc` (ISO 8601 UTC);
- `signal_number` integer and `applies_to` one of `ALL_BAY`, `NORTH_BAY`, `COASTAL_ZONES`, `NO_ACTIVE_MARINE_WARNING`;
- retain the original official URLs and a short context note.

The code rejects stale checks (>6h), missing issue/expiry, invalid scope, and ambiguous active-warning fields. **Do not set `NO_ACTIVE_MARINE_WARNING` or `signal_number: 0` just to make the indicator green.** Relevant official bulletins must be reviewed for their regional applicability; global caution is conservative and is not a location-specific forecast substitute. The app never produces an operationally certified `SAFE` status even if BMD is reviewed.

### Rule updates

Update `config/ban_rules_bd.json` with precise official effective dates, geographic applicability, vessel/species/gear, and source; run `pytest`. Included verified *date-only* hard gates: marine fishery closure **2026-04-15 to 2026-06-11** (all species, EEZ), mother Hilsa **2026-10-08 to 2026-10-29**, and juvenile Hilsa Jatka **2026-11-01 to 2027-06-30** (Jatka target only). These are not automatically repeated in future years. For MPA legality, obtain true signed zone/gear-specific maps; the included manual-derived overlays are only caution contextual layers. Review IFA trawler restrictions, location, and depth-class wording before any hard gate.

## Architecture and scientific method

```text
Private historical 1995–2025 + fisheries 2020–2025 + ground surveys
  -> Colab reference QC / frozen model (NOT YET IMPORTED or validated)
Live CMEMS + Open-Meteo -> HTTP clients -> units/time/spatial QC
BMD human check + dated DoF/MoFL rules + EEZ/IFA/GEBCO
  -> environmental screening / safety 72 h / sustainability
  -> priority legal/critical-hazard gating + data confidence
  -> versioned public/data/latest.json
  -> GitHub Pages offline-friendly PWA
  -> optional FastAPI read-only JSON endpoints
```

The **validated thesis PAI cannot be reconstructed** without its calibrated historic percentile bounds, AHP/TOPSIS ideals/weights, bias mappings, model artifacts and independent validation. The included `environment.screen` is deliberately marked `UNVALIDATED_ENVIRONMENTAL_SCREEN`, a transparent SST+SSS+Chl-a proxy. It is NOT PAI, fishability probability, or an estimate of CPUE. Environmental input gaps produce NULL, not manufactured values.

The safety thresholds follow the *provisional vessel classes* in the supplied methodology; no local fisher/regulator calibration is claimed. Weather score is a minimum across wave, wind, gust, visibility, and storm-code factors; if any parameter or forecast hour is missing, safety is UNKNOWN. Trip time uses an unvalidated 1.25× great-circle approximation and is not a safe navigable sea route. It does not result in a positive vessel safety clearance.

The regulations file separates **date-confirmed bans** from unverified gear/MPA claims. An intersecting MPA is displayed with a caution flag but is not automatically declared a universal fishing ban. Fishing grounds and IFA do not cause a stand-alone ban.

For any operational use, add official BMD and DoF approved warning/rules data flows, validated navigation-specific routes, local vessels' actual capabilities, independently measured sea-state skill, spatially and temporally held-out fisheries validation, reliable two-way alert delivery and governance approvals. Offline cache cannot update offshore without connectivity.

## Data / provenance notes

- The supplied EEZ ZIP and GEBCO NetCDF were read programmatically to create `public/data/grid.json`. The land/ocean selection is GEBCO elevation <−4 m, not a coastal navigation chart. EEZ source used as supplied and must be independently checked before legally consequential uses.
- The original R2 standalone HTML was inspected as a design reference but is deliberately **not republished** in this public repository: it may embed historical research evidence and contains an old non-NRT scenario engine. Retain the user-supplied original privately.
- Uploaded large research fisheries, survey workbooks and the historical Google Drive master are **not** uploaded to public GitHub. In-situ data are research evidence requiring confidentiality review, independent event validation, and geospatial consistency audit. Export a private UTF-8 CSV and run `tools/audit_fisheries_csv.py` locally to check event overlap; do not publish its raw output or identify fishers.
- Dataset source times and pipeline generated time are separate; a new JSON timestamp does **not** mean an underlying ocean or weather field is fresh. See `source_health` and individual forecast times.

## Testing and current release status

Run `python -m pytest -q`, `node --check public/app.js`, `node --check public/sw.js`. Backend unit tests cover noncompensatory ban priority, missing warnings, future-year non-assumptions, threshold hazard overrides, missing data, and non-certification. The code was checked locally with a no-network test snapshot; **no live external fetch has been proven within this file-building runtime** and the public GitHub deployment has not been performed. First deployment should therefore be monitored and adjusted to actual provider responses.

## External documentation

- https://open-meteo.com/en/docs/marine-weather-api
- https://open-meteo.com/en/docs
- https://open-meteo.com/en/terms
- https://toolbox-docs.marine.copernicus.eu/en/stable/python-interface.html
- https://data.marine.copernicus.eu/product/GLOBAL_ANALYSISFORECAST_PHY_001_024/description
- https://server6.bmd.gov.bd/en/p/Marine-Warning
- https://www.bmd.gov.bd/web/en/p/Fishermen-Forecast
- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
