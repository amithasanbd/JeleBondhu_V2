# Prior R2 prototype

The R2 HTML uploaded by the researcher was examined as the frontend and decision-engine reference. It is intentionally **not republished into a public GitHub repository** because the single-file application may embed historical research data, and its old scenario decision engine is not an operational NRT service. Keep the original uploaded file in private research storage. The new application is in `public/index.html`, `public/styles.css`, and `public/app.js`.
